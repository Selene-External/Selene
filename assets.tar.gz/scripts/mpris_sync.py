#!/usr/bin/env python3
import subprocess
import re
import json
import sys
import os

def get_mpris_data():
    try:
        # 1. Get all MPRIS players on session D-Bus
        players = []
        try:
            list_cmd = ['gdbus', 'call', '--session', '--dest', 'org.freedesktop.DBus', '--object-path', '/org/freedesktop/DBus', '--method', 'org.freedesktop.DBus.ListNames']
            res = subprocess.run(list_cmd, capture_output=True, text=True, timeout=1.5)
            players = re.findall(r"'(org\.mpris\.MediaPlayer2\.[^']+)'", res.stdout)
        except Exception:
            pass

        if not players:
            try:
                res = subprocess.run(['dbus-send', '--session', '--dest=org.freedesktop.DBus', '--type=method_call', '--print-reply', '/org/freedesktop/DBus', 'org.freedesktop.DBus.ListNames'], capture_output=True, text=True, timeout=1.5)
                players = re.findall(r'string "(org\.mpris\.MediaPlayer2\.[^"]+)"', res.stdout)
            except Exception:
                pass

        if not players:
            return {'c': False}

        # 2. Score and select best player
        best_player = None
        best_score = -1
        best_out = ""

        for p in players:
            try:
                mc = ['gdbus', 'call', '--session', '--dest', p, '--object-path', '/org/mpris/MediaPlayer2', '--method', 'org.freedesktop.DBus.Properties.GetAll', 'org.mpris.MediaPlayer2.Player']
                mr = subprocess.run(mc, capture_output=True, text=True, timeout=1)
                if mr.returncode != 0 or not mr.stdout:
                    continue

                out_str = mr.stdout
                is_playing = "'PlaybackStatus': <'Playing'>" in out_str
                is_spotify = ('spotify' in p.lower()) or ('spotify.com' in out_str.lower())
                has_track = "'xesam:title'" in out_str

                score = 0
                if is_spotify and is_playing:
                    score = 100
                elif is_spotify and has_track:
                    score = 80
                elif is_playing and has_track:
                    score = 50
                elif has_track:
                    score = 20
                else:
                    score = 5

                if score > best_score:
                    best_score = score
                    best_player = p
                    best_out = out_str
            except Exception:
                pass

        if not best_player or not best_out:
            return {'c': False}

        out = best_out
        st = "'PlaybackStatus': <'Playing'>" in out
        
        t = re.findall(r"'xesam:title':\s*<'([^']+)'", out)
        a = re.findall(r"'xesam:artist':\s*<\[\s*'([^']+)'", out)
        if not a:
            a = re.findall(r"'xesam:artist':\s*<'([^']+)'", out)
            
        alb = re.findall(r"'xesam:album':\s*<'([^']+)'", out)
        art = re.findall(r"'mpris:artUrl':\s*<'([^']+)'", out)
        url = re.findall(r"'xesam:url':\s*<'([^']+)'", out)
        ln = re.findall(r"'mpris:length':\s*<int64\s+([0-9]+)>", out)
        ps = re.findall(r"'Position':\s*<int64\s+([0-9]+)>", out)
        
        dur = float(ln[0]) / 1000000.0 if ln else 0.0
        pos = float(ps[0]) / 1000000.0 if ps else 0.0
        
        is_sp = ('spotify' in best_player.lower()) or ('spotify.com' in out.lower()) or (url and 'spotify.com' in url[0])
        
        if 'spotify' in best_player.lower():
            p_name = "Spotify App"
        elif is_sp:
            p_name = "Spotify Web"
        elif 'firefox' in best_player.lower():
            p_name = "Firefox Media"
        elif any(b in best_player.lower() for b in ['chrome', 'chromium', 'brave', 'edge']):
            p_name = "Browser Media"
        else:
            p_name = "Media Player"
        
        return {
            'c': True,
            'p': best_player,
            'pn': p_name,
            'st': st,
            't': t[0] if t else ('Spotify' if is_sp else 'Unknown Title'),
            'a': a[0] if a else 'Artist',
            'alb': alb[0] if alb else '',
            'art': art[0] if art else '',
            'dur': dur,
            'pos': pos
        }
    except Exception:
        return {'c': False}

if __name__ == '__main__':
    data = get_mpris_data()
    print(json.dumps(data, ensure_ascii=False))
